<?php

require_once "connection.php";

if(isset($_POST['submit_1'])){
    echo '<script>alert("There is no user registered for that email address")</script>'; 
    $email = $_POST['email'];

    $sql = "SELECT * FROM user WHERE email = '$email';";
    $result = $con-> query($sql);
    if($result){
        if($result->num_rows > 0){
            while($row = mysql_fetch_array($result)){
                echo '<script>
                    var x = document.getElementById("securitryQuestion");
                    if (window.getComputedStyle(x).display === "none") {
                        x.style.display = "block";
                    }
                    document.getElementById("securitryQuestionText").innerHTML = "'.$row['security_a'].'";
            </script>';
            
            }
        }
        else{
            echo '<script>alert("There is no user registered for that email address")</script>'; 
        }
    }
}
else if(isset($_POST['submit_2'])){
    $answer = $_POST['answer'];
    $sql = "SELECT * FROM user WHERE email = ".$email."AND security_a = ".$answer.";";
    $result = $con-> query($sql);
    if($result){
        if($result->num_rows > 0){
            while($row = mysql_fetch_array($result)){
                echo '<script>
                    var x = document.getElementById("newPassword");
                    if (window.getComputedStyle(x).display === "none") {
                        x.style.display = "block";
                    }

            </script>';
            
            }
        }
        else{
            echo '<script>alert("Your Answer is wrong")</script>'; 
        }
    }
}
else if(isset($_POST['submit_3'])){

    $newpass = $_POST['pass1'];
    $newpassconfirm = $_POST['pass2'];

    if($newpass != $newpassconfirm){
        echo '<script>alert("Password you entered do not match")</script>';
    }
    else if (strlen($newpass) < 7){
        echo '<script>alert("Password should contain at least 8 characters")</script>';
    }
    else{
        $sql = "UPDATE user set password = ".$newpass." where email =".$email.";";
        $result = $con-> query($sql);
        if($result){
            echo '<script>alert("Password updated successfully!")</script>'; 
            header("Location:login.php");
        }
    }
}

?>