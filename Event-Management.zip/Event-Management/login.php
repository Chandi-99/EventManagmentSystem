<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">

    <script>
      let tagArr = document.getElementsByTagName("input");
      for (let i = 0; i < tagArr.length; i++) {
        tagArr[i].autocomplete = 'off';
      }
    </script>
</head>

<body>
    <!-- header section -->
    <!-- <section class="banner" role="banner" id="banner"> -->
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="index.php">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index.php">Home</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>

    <!-- </section> -->
    <!-- header section -->

    <!-- login section -->
    <section id="contact" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Login</h2>
                <p class="wow fadeInDown animated">Please login to proceed further</p>
            </div>
            <div class="row">
                <div class=" conForm">
                    <form method="post" action="login.php" autocomplete="off">
                        <input name="username" id="username" type="text"  placeholder="User name" tag="input" >
                        <br>
                        <input name="password" id="password" type="password"  placeholder="Password" tag="input">
                        <br>
                        <p class="wow fadeInDown animated"> <b><a href="forgotPass.php">Forgot Password</a></b> ?</p>

                        <input type="submit" id="login" name="login" class="submitBnt" value="Login" >
                    </form>
                </div>
            </div>
            <div class="section-header">
                <p class="wow fadeInDown animated">New to <b><a href="signup.php">Best Events</a></b> ?</p>
            </div>
        </div>
    </section>
    <!-- login section -->

    <!-- JS FILES -->
    <script src="../../../ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/jquery.countdown.js"></script>
    <script type="text/javascript" src="js/global.js"></script>
    <script type="text/javascript" src="js/jquery.contact.js">
      /*  $( document ).ready(function() {
            setTimeout(function(){
            $("#username").attr('readonly', false);
            $("#username").focus();
            },500);
        });

        }*/
</script>
<?php
session_start();
require_once "connection.php";
$error = FALSE;

if(isset($_POST['login'])){
    if(empty($_POST['username'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the user name ")</script>'; 
    }else if(empty($_POST['password'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the password ")</script>'; 
    }
    
    if(!$error){
        $username1 = $_POST['username'];
        $password1 = $_POST['password'];
    
        $username1 = stripcslashes($username1);  
        $password1 = stripcslashes($password1);  
        $username1 = mysqli_real_escape_string($con, $username1);  
        $password1 = mysqli_real_escape_string($con, $password1);  
    
        $sql = "SELECT * FROM user WHERE user_name = '$username1' AND password = '$password1';";
        $result = $con-> query($sql);
    
        if($result){
            if($result->num_rows > 0){
    
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
                $usertype = $row['user_type'];
                $userid = $row['user_id']; 
        
                if($usertype == "customer"){
                    $sql = "SELECT * FROM customer WHERE user_id = '$userid';";
                    $result_1 = $con-> query($sql);
                   
                    $row_1 = mysqli_fetch_array($result_1, MYSQLI_ASSOC);  
                    $customer_id = $row_1['customer_id'];
                    $_SESSION['customer_id'] = $customer_id;
                    header("Location:customerPanel.php");       
                
                }
                else if($usertype == "service provider"){
                    $sql = "SELECT * FROM service_provider WHERE user_id = '$userid';";
                    $result_1 = $con-> query($sql);
                   
                    $row_1 = mysqli_fetch_array($result_1, MYSQLI_ASSOC);  
                    $sp_id = $row_1['sp_id'];
                    $_SESSION['sp_id'] = $sp_id;
                    header("Location:serviceProviderPanel.php");
                    
                }
                else if($usertype == "admin"){
                    $_SESSION['user_id'] = $userid;
                    header("Location:adminPanel.php");
                }
            }
             else{
                echo '<script>alert("Invalid Username or Password")</script>'; 
            }
        }
        else{    
            echo '<script>alert("Invalid Username or Password")</script>';      
            
        }
    }
}
?>
</body>

</html>