<?php

require_once "connection.php";
session_start();
$spid = $_SESSION['sp_id'];
$error = FALSE;


?>
<!doctype html>
<html class="no-js" lang="">


<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            color: #ff5518;
            font-family: monospace;
            font-size: 25px;
            text-align: center;
        }

        th {
            background-color: #ff5518;
            color: #1e1e1e;
            text-align: center;
        }

        td{
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #bcbcbc;
        }
    </style>
</head>

<body>
    <!-- header section -->
    <!-- <section class="banner" role="banner" id="banner"> -->
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="#">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="#newpackage">Create New Package</a></li>
                    <li><a href="#editpackage">Edit Package</a></li>
                    <li><a href="#vieworder">View Orders</a></li>
                    <li><a href="index_new.php">Home</a></li>
                    <li><a href="login.php">Logout</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>

    <!-- </section> -->
    <!-- header section -->

    <!-- services section -->
    <section id="services" class="services service-section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated" id="sp_name">Welcome back Service Provider</h2>
                <!-- <p class="wow fadeInDown animated">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eget risus vitae massa <br> semper aliquam quis mattis quam.</p> -->
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-recycle"></span>
                    <div class="services-content">
                        <!-- <h5>Musical Night</h5>
            <b>Day 1</b> -->
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis eu libero scelerisque ligula sagittis faucibus eget quis lacus.</p> -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-heart"></span>
                    <div class="services-content">
                        <!-- <h5>Dancing Night</h5>
            <b>Day 2</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis eu libero scelerisque ligula sagittis faucibus eget quis lacus.</p> -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-megaphone"></span>
                    <div class="services-content">
                        <!-- <h5>Food Night</h5>
            <b>Day 3</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis eu libero scelerisque ligula sagittis faucibus eget quis lacus.</p> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- services section -->

    <!-- new package section -->
    <section id="newpackage" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Add New Package</h2>
                <!-- <p class="wow fadeInDown animated">Please signup to proceed further</p> -->
            </div>
            <div class="row">
                <div class=" conForm">
                    <form method="post" action="serviceProviderPanel.php" name="lform" id="lform" >

                        <input name="packname" id="packname" type="text" placeholder="Package Name">
                        <br>
                        <input name="value" id="value" type="number" placeholder="Value">
                        <br>
                        <textarea style="width:500px;" name="packdes" id="packdes" cols="" rows="" placeholder="Package Discription..."></textarea>
                        <br>
                        <input type="submit" id="signup" name="addPack" class="submitBnt" value="Add Package">
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- new package section -->

    <!-- edit package section -->
    <section id="editpackage" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Edit Package</h2>
                <p class="wow fadeInDown animated">Enter Package Name to update</p>
                <br>
                <div class=" conForm" id="editPackage">
                    <form method="post" action ="serviceProviderPanel.php">
                    <input name="packname" id="regNum" type="Text" required placeholder="Enter Package Name"><br>
                    <input type="submit" style="width: 220px;" id="getSP" name="getPack" class="submitBnt" value="Get Details">
                    </form> 

                </div>
            </div>

            <div class=" conForm" id="packageDetails" style="display: none;">
                <form method="post" name="packageDetailsform" id="packageDetailsform" action="serviceProviderPanel.php" >
                    <input name="packname" id="packname" type="text" placeholder="Package Name">
                    <br>
                    <input type="number" id="value" name="value" placeholder="Value">
                    <br>
                    <textarea style="width:500px;" name="packdesc" id="packdes" cols="" rows="" placeholder="Package Discription..."></textarea>
                    <br>
                    <input type="submit" id="signup" name="updatePack" class="submitBnt" value="Add Package">
                </form>
            </div>

        </div>
    </section>
    <!-- edit package section -->

    <!-- view orders section -->
    <section id="vieworder" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">All Orders</h2>
            </div>
            <table>
                <tr>
                    <th>Event ID</th>
                    <th>Package ID</th>
                    <th>Event Name</th>
                    <th>Date</th>
                    <th>Venue</th>
                    <th>Time</th>
                    <th>Service Charge</th>

                </tr>
<?php

    $sql = "SELECT * FROM sp_event WHERE sp_id ='$spid';";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {

   // echo '<script>alert("hii 1")</script>'; 
     while ($row = $result->fetch_assoc()) {

        $eventid = $row["event_id"];
        $sql = "SELECT * FROM event WHERE event_id ='$eventid';";
        $result_1 = $con->query($sql);

        if($result_1){
            //echo '<script>alert("hii 2")</script>'; 
            while($row_1 = $result_1->fetch_assoc()){
                $packageid = $row["package_id"];
                $sql = "SELECT * FROM package WHERE package_id ='$packageid';";
                $result_2 = $con->query($sql);

                if($result_2){
                    //echo '<script>alert("hii 3")</script>'; 
                    while($row_2 = $result_2->fetch_assoc()){

                        echo "<tr><td>" . $row_1["event_id"] . "</td><td>" . $row_2["package_id"]."</td><td>" . $row_1["event_name"]."</td><td>" . $row_1["date"] . "</td><td>" . $row_1["venue"] .
                        "</td><td>" . $row_1["start_time"] . "</td><td>". $row_2["value"] . "</td></tr>";
                    }
                    unset($result_2);
                }  
                else{
                    echo "Error in ".$sql."<br>".$con->error; 
                }  
            }
            unset($result_1);
        }
        else{
            echo "Error in ".$sql."<br>".$con->error; 
        }   
     }
     echo "</table>";
 } else {
    echo "Error in ".$sql."<br>".$con->error; 
 }

?>
            </table>
        </div>
    </section>

   <?php
   
    require_once "connection.php";
    $spid = $_SESSION['sp_id'];
    $sql = 'SELECT * FROM service_provider where sp_id = '.$spid.';';
    if($result_3 = $con-> query($sql)){
        if($result_3){
            
            $row_3 = mysqli_fetch_array($result_3, MYSQLI_ASSOC);  
            $sp_name = $row_3['name'];
        }
        else{
            echo "Error in ".$sql."<br>".$con->error;
        }
    }
    else{
        echo "Error in ".$sql."<br>".$con->error;
    }
?>

<?php

    if(!empty($_POST['addPack'])){

        $error = FALSE;

        if(empty($_POST['packname'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the Package name ")</script>'; 
        }else if(empty($_POST['value'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the Value of the Package ")</script>'; 
        }
        else if(empty($_POST['packdes'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the Package Description ")</script>'; 
        }
        else{
            $packname = $_POST["packname"];
            $value = $_POST["value"];
            $packdes = $_POST["packdes"];

            $packname = stripcslashes($packname);
            $value = stripcslashes($value);  
            $packdes = stripcslashes($packdes);

            $packname = mysqli_real_escape_string($con, $packname);
            $value = mysqli_real_escape_string($con, $value);
            $packdes = mysqli_real_escape_string($con, $packdes);
        }

        if(!$error){
            $sql = "INSERT INTO package VALUES (0,'$spid','$packdes','$value','$packname');";
            $result = $con-> query($sql);
            if($result){
                echo '<script>alert("Package created successfully!")</script>';
            }
            else{
                echo "Error in ".$sql."<br>".$con->error;
            } 
        }

    }
    else if(!empty($_POST['getPack'])){
        $error = FALSE;
        if(empty($_POST['packname'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the Package Name")</script>'; 
        }
        else if(!$error){

            $packname = $_POST['packname']; 
            $packname = stripcslashes($packname);  
            $packname = mysqli_real_escape_string($con, $packname);  
         
            $sql = "SELECT * FROM package WHERE package_name = '$packname';";
            $result = $con-> query($sql);
     
            if($result){
     
                if($result->num_rows > 0){

                    while($row = mysqli_fetch_array($result)){

                        echo '<script>                     
                        var x = document.getElementById("packageDetails");
                        if (window.getComputedStyle(x).display === "none") {
                            x.style.display = "block";   
                        }</script>';
                        $field1 = $row['package_name'];
                        $field2 = $row['value'];
                        $field3 = $row['pack_des'];

                        $pack_id = $row['package_id'];
                        $_SESSION['pack_id'] = $pack_id;

                        $_SESSION['field1'] = $field1;
                        $_SESSION['field2'] = $field2;
                        $_SESSION['field3'] = $field3;

                        echo '<script>
                        var x = document.getElementById("packageDetails");
                        if (window.getComputedStyle(x).display === "none") {
                            x.style.display = "block";
                        }
                        </script>';

                        echo '<script>alert("Package found! Fill the input Field you wish to update")</script>';

                    }

                }
                else{
                    echo '<script>alert("There is no Package registered for that Package Name")</script>';
                    $error = FALSE;
                }

            } 
            else{
                echo "Error in ".$sql."<br>".$con->error;
            } 

        }

    }
    else if(!empty($_POST['updatePack'])){

       
        $error = FALSE;

        global $field1;
        global $field2;
        global $field3;

        $sp_id = $_SESSION['spid'];
        $package_id = $_SESSION['pack_id'];

        $namechng = FALSE;
        $valuechng = FALSE;
        $packdeschng = FALSE;

        if(!empty($_POST['packname'])){

            if($field1 != $_POST['packname']){
                $namechng = TRUE;
            }
        }else if(!empty($_POST['value'])){
           
            if($field2 != $_POST['value']){
                $valuechng = TRUE;
            }
        }
        else if(!empty($_POST['packdesc'])){
            
            if($field3 != $_POST['packdesc']){
                $packdeschng = TRUE;
            }
        }

        if(!$error){
            if($namechng){

                $newname = $_POST['packname'];
                $sql = "UPDATE package set `package_name` = '$newname' WHERE package_id = '$package_id';";
                $result = $con-> query($sql);
                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }
            }

            if($valuechng){

                $newvalue = $_POST['value'];
                $sql = "UPDATE package set `value` = '$newvalue' WHERE package_id = '$package_id';";
                $result = $con-> query($sql);
                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }
            }

            if($packdeschng){

                $newpackdes = $_POST['packdesc'];
                $sql = "UPDATE package set `pack_des` = '$newpackdes' WHERE package_id = '$package_id';";
                $result = $con-> query($sql);
                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }
            }

            echo '<script>alert("Package information Updated Successfully!")</script>';
            $error = FALSE;

        }

    }

    ?>
    <!-- JS FILES -->
    <script src="../../../ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/jquery.countdown.js"></script>
    <script type="text/javascript" src="js/global.js"></script>
    <script type="text/javascript" src="js/jquery.contact.js"></script>
    <script type="text/javascript">
    var php_var = "<?php echo $sp_name; ?>";
   document.getElementById("sp_name").innerHTML =  "Welcome back " +php_var;
    </script>


</body>

</html>