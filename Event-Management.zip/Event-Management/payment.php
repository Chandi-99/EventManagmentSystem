<?php
require_once "connection.php";
session_start();
$error = FALSE;

if(empty($_SESSION['customer_id'])){
    echo '<script>alert("Please Log into the system")</script>';
    header("Location:login.php");
}
else{
    $customerid = $_SESSION['customer_id'];
    $eventid = $_SESSION['event_id'];
    //echo $eventid;
}
?>
<!doctype html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css"> 
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">

    <style rel="stylesheet" type="text/css">

select{
        color: #797979;
	    padding: 15px 30px;
	    width:500px;
	    border: none;
	    margin-bottom: 30px;
	    outline: none;
	    font-style: normal;
	    border: #e0e0e0 1px solid;
	    font-size: 15px;
	    background: #010101;
    }

    lb{
        color: #797979;
	    padding: 15px 30px;
	    width:500px;
	    border: none;
	    margin-bottom: 30px;
	    outline: none;
	    font-style: normal;
	    border: #e0e0e0 1px solid;
	    font-size: 15px;
	    background: #010101;
    }

    select{
        color: #797979;
	    padding: 15px 30px;
	    width:500px;
	    border: none;
	    margin-bottom: 30px;
	    outline: none;
	    font-style: normal;
	    border: #e0e0e0 1px solid;
	    font-size: 15px;
	    background: #010101;
    }

    table {
            border-collapse: collapse;
            width: 100%;
            color: #ff5518;
            font-family: monospace;
            font-size: 25px;
            text-align: center;
        }

        th {
            background-color: #ff5518;
            color: #1e1e1e;
            text-align: center;
            padding:10px;
        }

        td{
            text-align: center;
            padding:10px;
        }

        tr:nth-child(even) {
            background-color: #bcbcbc;
        }
        tr:nth-child(odd) {
            color:black;
        }

        </style>

    </head>

<body>
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="index.php">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index_new_1.php">Home</a></li>
                    <li><a href="login.php">Logout</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>

    <section id="events" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Order Details</h2>
            </div>
            <table>
                <tr>
                    <th>Service Type</th>
                    <th>SP Name</th>
                    <th>Package Id</th>
                    <th>Package Name</th>
                    <th>Package Description</th>
                    <th>Value</th>
                </tr>

                <?php
                require_once "connection.php";
                $total = 0;
                global $eventid;

                //echo $eventid;
                $sql = "SELECT * FROM sp_event WHERE event_id='$eventid';";
                $result = $con->query($sql);

                if($result){
                    //show data next
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }
                unset($row);
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                $row_count = $result->num_rows;
                //echo $row_count;
                if ($result->num_rows > 0) {


                    while ($row = $result->fetch_assoc()) {

                        $packid = $row['package_id'];
                        $sql = "SELECT * FROM package WHERE package_id ='$packid';";
                        $result_3 = $con->query($sql);
                        $row_1 = mysqli_fetch_array($result_3, MYSQLI_ASSOC);
                        $spid = $row_1['sp_id']; 
                        $sql = "SELECT * FROM service_provider WHERE sp_id ='$spid';";
                        $result_4 = $con->query($sql);
                        $row_2 = mysqli_fetch_array($result_4, MYSQLI_ASSOC);
                        $total += $row_1['value'];

                        echo "<tr><td>". $row_2["sp_type"]."</td><td>". $row_2["name"] . "</td><td>" . $row_1["package_id"] . "</td><td>"
                            . $row_1["package_name"] . "</td><td>". $row_1["pack_des"] ."</td><td>". $row_1["value"]. "</td></tr>";
                        unset($result_3);
                        unset($result_4);
                        unset($row_1);
                        unset($row_2);
                        $row_count--;
                    }
                    echo "</table>";
                }
                else {
                    
                }
                
                ?>

            </table>
        </div>
    </section>
    <section  class="section" class="container" class="conForm" >        
        
            <div class=" conForm" id="billdetails">
            <h2 class="wow fadeInDown animated">Payment Information</h2>
            <br>
                <form method="post" name="customerDetailsform"  action="payment.php">
                <lb>Payment Method:</lb><select name="payment_type">   
                        <option>Cash</option>
                        <option>Card Payment</option>
                </select>
                    <br>
                    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<lb>Discount:</lb><input name="discount" id="discount" type="number" readonly="true" value="0">
                    <br>
                    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<lb>Advanced:</lb><input name="advanced" id="advanced" type="number" >
                    <br>
                    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<lb>Total:</lb><input name="total" id="total" type="number" value= <?php echo $total?>  readonly="true">
                    <br>
                    <input type="submit" style="width: 250px;"  name="addtobill" class="submitBnt" value="PAY"><br>
                    </form>
                    <form method="post" name="customerDetailsform"  action="payment.php">
                    <input type="submit" style="width: 250px;"  name="cancel" class="submitBnt" value="Cancel">
                    </form>

            </div>
            </section>
    </body>

    <?php

require_once "connection.php";
$error = FALSE;

global $eventid;
global $customerid;


if(!empty($_POST['addtobill'])){

    if(empty($_POST['advanced'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the Advanced Payment Amount")</script>'; 
    }
    else{
        $advanced = $_POST["advanced"];
        $pt = $_POST["payment_type"];
        $advanced = stripcslashes($advanced);  
        $advanced = mysqli_real_escape_string($con, $advanced);

        echo $eventid;
        $sql = "SELECT * from bill where event_id='$eventid';";
        $result = $con->query($sql);
    
        /*if($result){
            $error = TRUE;
            echo '<script>alert("Bill already generated for the corresponding event!")</script>'; 
        }
        else{
            echo "Error in ".$sql."<br>".$con->error;
        }*/
    }

    /*if(!$error){
                
        $sql = "SELECT * FROM temp ;";
        $result = $con-> query($sql);
        unset($row);

        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $row_count = $result->num_rows;

        if($row_count == 0){
            echo '<script>alert("Please Select At least one package!")</script>';
            $error = TRUE:
        }
        else if($row_count == 1){
            $pk1 =$row["package_id"];
            $packcount = 1;

            $sql = "SELECT sp_id from package where package_id = '$pk1';";
            $result = $con-> query($sql);
            $row_3 = mysqli_fetch_array($result, MYSQLI_ASSOC);
            


            if($result){                   

            }
            else{
                echo "Error in ".$sql."<br>".$con->error;
            }
        }
        else if($row_count == 2){
            while ($row = $result->fetch_assoc()) {
                $pk1 = $row['package_id'];

                if($row_count == 1){
                    $pk2 = $row['package_id'];
                }
                $row_count--;
            }

            $packcount = 2;
        }
        else if($row_count == 3){
            while ($row = $result->fetch_assoc()) {
                $pk1 = $row['package_id'];

                if($row_count == 1){
                    $pk2 = $row['package_id'];
                }
                if($row_count == 2){
                    $pk3 = $row['package_id'];
                }
                $row_count--;
            }

            $packcount = 3;
        }
        else if($row_count == 4){
            while ($row = $result->fetch_assoc()) {
                $pk1 = $row['package_id'];

                if($row_count == 1){
                    $pk2 = $row['package_id'];
                }
                if($row_count == 2){
                    $pk3 = $row['package_id'];
                }
                if($row_count == 3){
                    $pk4 = $row['package_id'];
                }
                $row_count--;
            }

            $packcount = 4;
        }


    }*/

    if(!$error){
        $pt = $_POST["payment_type"];
        $sql = "INSERT into bill values(0,'$pt','$advanced','0','$total','$eventid');";
        $result = $con->query($sql);
    
        if($result){
            echo '<script>alert("Packages Added to the bill Successfully!")</script>';
            $url = "customerPanel.php";

            if (!headers_sent())
            {    
                header('Location: '.$url);
                exit;
            }
            else
            {  
                echo '<script type="text/javascript">';
                echo 'window.location.href="'.$url.'";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
                echo '</noscript>'; exit;
            }

        }
        else{
            echo "Error in ".$sql."<br>".$con->error;
        }

    }
}
else if(!empty($_POST['cancel'])){

    $sql = "DELETE from sp_event WHERE event_id= '$eventid' ;";
    $result = $con->query($sql);

    if($result){
        $url = "customerPanel.php";

        if (!headers_sent())
        {    
            header('Location: '.$url);
            exit;
        }
        else
        {  
            echo '<script type="text/javascript">';
            echo 'window.location.href="'.$url.'";';
            echo '</script>';
            echo '<noscript>';
            echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
            echo '</noscript>'; exit;
        }
    }
    else{
        echo "Error in ".$sql."<br>".$con->error;
    }

   
}

    ?>

</html>