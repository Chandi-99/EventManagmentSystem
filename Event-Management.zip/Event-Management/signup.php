<?php
session_start();
require_once "connection.php";
$error = FALSE;
?>
<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">
</head>

<body>
    <!-- header section -->
    <!-- <section class="banner" role="banner" id="banner"> -->
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="index.php">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>

    <!-- </section> -->
    <!-- header section -->

    <!-- signup section -->
    <section id="contact" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Signup</h2>
                <p class="wow fadeInDown animated">Please signup to proceed further</p>
            </div>
            <div class="row">
                <div class=" conForm">
                    <form method="post" onClick = "validate()" action="signup.php" name="lform" id="lform">

                        <input name="name" id="name" type="text" placeholder="First Name / User Name">
                        <br>
                        <input name="lname" id="lname" type="text" placeholder="Last Name">
                        <br>
                        <input name="address" id="address" type="text" placeholder="Address">
                        <br>
                        <input name="nic" id="nic" type="text" placeholder="NIC Number">
                        <br>
                        <input name="dob" id="dob" type="date" placeholder="Date of Birth">
                        <br>
                        <input name="mnumber" id="mnumber" type="number" placeholder="Mobile Number">
                        <br>
                        <input name="email" id="email" type="email" placeholder="Email Address">
                        <br>
                        <input name="sec_q" id="sec_q" type="text" placeholder="Enter Security Question">
                        <br>
                        <input name="sec_a" id="sec_a" type="text" placeholder="Enter Answer">
                        <br>
                        <input name="password" id="password" type="password" placeholder="Password">
                        <br>
                        <input name="cpassword" id="cpassword" type="password" placeholder="Confirm Password">
                        <br>
                        <input type="submit" onClick ="validate()" id="signup" name="signup" class="submitBnt" value="Signup">
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- signup section -->

    <!-- JS FILES -->
    <script src="../../../ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/jquery.countdown.js"></script>
    <script type="text/javascript" src="js/global.js"></script>
    <script type="text/javascript" src="js/jquery.contact.js"></script>
    <script type="text/javascript">

        /*function allLetter(var string){
            var letters = /^[A-Za-z]+$/;
            if(string.value.match(letters)){
                return true;
            }
            else{
                return false;
            }
        }*/
        $( document ).ready(function() {
            setTimeout(function(){
            $("#emailh").attr('readonly', false);
            $("#emailh").focus();
            },500);
        });

        }
    </script>

    <?php

if(isset($_POST['signup'])){

    if(empty($_POST['name'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the first name ")</script>'; 
    }else if(empty($_POST['lname'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the last name ")</script>'; 
    }
    else if(empty($_POST['address'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the address ")</script>'; 
    }
    else if(empty($_POST['nic'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the NIC number ")</script>'; 
    }    else if(empty($_POST['mnumber'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the phone number ")</script>'; 
    }
    else if(empty($_POST['email'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the email address ")</script>'; 
    }
    else if(empty($_POST['password'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the password ")</script>'; 
    }
    else if(empty($_POST['cpassword'])){
        $error = TRUE;
        echo '<script>alert("Please confirm the password ")</script>'; 
    }
    else if(empty($_POST['sec_q'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the security question ")</script>'; 
    }
    else if(empty($_POST['sec_a'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the security answer ")</script>'; 
    }
    else if(empty($_POST['dob'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the date of birth ")</script>'; 
    }
    else{

        $name = $_POST["name"];
        $lname = $_POST["lname"];
        $address = $_POST["address"];
        $nic = $_POST["nic"];
        $mnumber = $_POST["mnumber"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $cpassword = $_POST["cpassword"];
        $sec_q = $_POST["sec_q"];
        $sec_a = $_POST["sec_a"];
        $dob = $_POST["dob"];

        $name = stripcslashes($name);
        $lname = stripcslashes($lname);
        $address = stripcslashes($address);  
        $nic = stripcslashes($nic);
        $mnumber = stripcslashes($mnumber); 
        $email = stripcslashes($email); 
        $password = stripcslashes($password); 
        $cpassword = stripcslashes($cpassword); 
        $sec_q = stripcslashes($sec_q); 
        $sec_a = stripcslashes($sec_a); 
        $dob = stripcslashes($dob); 


        $name = mysqli_real_escape_string($con, $name);
        $lname = mysqli_real_escape_string($con, $lname); 
        $address = mysqli_real_escape_string($con, $address);
        $nic = mysqli_real_escape_string($con, $nic);
        $mnumber = mysqli_real_escape_string($con, $mnumber);
        $email = mysqli_real_escape_string($con, $email);
        $password = mysqli_real_escape_string($con, $password);
        $cpassword = mysqli_real_escape_string($con, $cpassword);
        $sec_a = mysqli_real_escape_string($con, $sec_a);
        $sec_q = mysqli_real_escape_string($con, $sec_q);
        $dob = mysqli_real_escape_string($con, $dob);

    }

    if(!$error){
        if(strlen($mnumber) != 10){
            $error = TRUE;
            echo '<script>alert("Please Enter a valid mobile number ")</script>'; 
        }
        else if($password != $cpassword){
            $error = TRUE;
            echo '<script>alert("Passwords does not match ")</script>'; 
        }
        else if (strlen($password) < 7){
            $error = TRUE;
            echo '<script>alert("Password should contain at least 8 characters")</script>';
        }
        else{

            $sql = "SELECT * FROM user where user_name='$name';";
            $result_3 = $con-> query($sql);
            if($result_3){
            if($result_3->num_rows > 0){
                $error = TRUE;
                echo '<script>alert("User name already taken ")</script>'; 
            }
            else{
                $sql = "INSERT INTO user VALUES (0,'$name','$password','customer','$sec_q','$sec_a','$email');";
                $result = $con-> query($sql);
    
                if($result){
                    $sql = "SELECT * FROM `user` WHERE user_id=(SELECT MAX(user_id) FROM `user`);";
                    $result_1 = $con-> query($sql);
                    $row = mysqli_fetch_array($result_1, MYSQLI_ASSOC);
                    $userid = $row['user_id'];
    
                    $sql = "INSERT INTO customer VALUES (0,'$name','$lname','$nic','$dob','$mnumber', '$userid');";
                    $result_2 = $con-> query($sql);
                    if($result_2){
                        echo '<script>alert("Account created successfully!")</script>';
                    }
                    else{
                        echo "Error in ".$sql."<br>".$con->error;
                    } 
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }
        
            }
        }

           
        }

    }
    
}



 ?>

</body>

</html>