<?php
session_start();
    require_once "connection.php";
    $error = FALSE;

?>
<!doctype html>
<html class="no-js" lang="">


<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            color: #ff5518;
            font-family: monospace;
            font-size: 25px;
            text-align: left;
        }

        th {
            background-color: #ff5518;
            color: #1e1e1e;
        }

        tr:nth-child(even) {
            background-color: #bcbcbc;
        }

        select{
        color: #797979;
	    padding: 15px 30px;
	    width:500px;
	    border: none;
	    margin-bottom: 30px;
	    outline: none;
	    font-style: normal;
	    border: #e0e0e0 1px solid;
	    font-size: 15px;
	    background: #010101;
    }
    </style>


</head>

<body>
    <!-- header section -->
    <!-- <section class="banner" role="banner" id="banner"> -->
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="#">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="#newSP">Create SP</a></li>
                    <li><a href="#editSP">Edit SP</a></li>
                    <li><a href="#editcustomer">Edit Customer</a></li>
                    <li><a href="#inquireies">View Inquiries</a></li>
                    <li><a href="#events">Ongoing Events</a></li>
                    <li><a href="index_new_2.php">Home</a></li>
                    <li><a href="login.php">Logout</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>

    <!-- </section> -->
    <!-- header section -->

    <!-- services section -->
    <section id="services" class="services service-section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Welcome back Admin</h2>
                <!-- <p class="wow fadeInDown animated">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eget risus vitae massa <br> semper aliquam quis mattis quam.</p> -->
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-recycle"></span>
                    <div class="services-content">
                        <!-- <h5>Musical Night</h5>
            <b>Day 1</b> -->
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis eu libero scelerisque ligula sagittis faucibus eget quis lacus.</p> -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-heart"></span>
                    <div class="services-content">
                        <!-- <h5>Dancing Night</h5>
            <b>Day 2</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis eu libero scelerisque ligula sagittis faucibus eget quis lacus.</p> -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-megaphone"></span>
                    <div class="services-content">
                        <!-- <h5>Food Night</h5>
            <b>Day 3</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis eu libero scelerisque ligula sagittis faucibus eget quis lacus.</p> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- services section -->

    <!-- addSP section -->
    <section id="newSP" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Create New Service Provider</h2>
                <p class="wow fadeInDown animated">Fill the required field to add new Service Provider</p>
                <br>
            </div>
            <div class="row">
                <div class=" conForm">
                    <form method="post" action="adminPanel.php" name="addSPform" id="addSPform">
                        <input name="name" id="name" type="text" placeholder="Company Name / User Name">
                        <br>
                        <input name="address" id="address" type="text" placeholder="Address">
                        <br>
                        <input name="mnumber" id="mnumber" type="text" placeholder="Mobile Number">
                        <br>
                        <input name="regnumber" id="spRegNum" type="text" placeholder="Service Provider Register Number">
                        <br>
                        <select name="sptype">   
                        <option>venue and catering</option>
                        <option>themes and concept</option>
                        <option>decoration</option>
                        <option>entertainment</option>       
                        </select>
                        <br>
                        <input name="email" id="email" type="email" placeholder="Email Address">
                        <br>
                        <input name="sec_q" id="sec_q" type="text" placeholder="Enter Security Question">
                        <br>
                        <input name="sec_a" id="sec_a" type="text" placeholder="Enter Answer">
                        <br>
                        <input name="password" id="password" type="password" placeholder="Password">
                        <br>
                        <input name="cpassword" id="cpassword" type="password" placeholder="Confirm Password">
                        <br>
                        <input type="submit" id="addSP" name="addSP" class="submitBnt" value="Add SP">
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- addSP section -->

    <!-- editSP section -->
    <section id="editSP" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Edit Service Provider</h2>
                <p class="wow fadeInDown animated">Enter Company Email Address to update Service Provider</p>
                <br>
                <div class=" conForm" id="editSPForm">
                <form method="post" action="adminPanel.php" name="editSP" id="addSPform">
                    <input name="email" id="email" type="email" required placeholder="Enter Service Provider Email Address"><br>
                    <input type="submit" style="width: 220px;" id="getSP" name="getSP" class="submitBnt" value="Check SP">
                </form>

                </div>
            </div>

            <div class=" conForm" id="spDetails" style="display: none;">
                <form method="post" name="spDetailsform" id="spDetailsform" action="adminPanel.php">
                    <input name="name" id="Name" type="text" placeholder="Company Name">
                    <br>
                    <input name="address" id="Address" type="text" placeholder="Address">
                    <br>
                    <input name="mnumber" id="Mnumber" type="text" placeholder="Mobile Number">
                    <br>
                    <input name="regnumber" id="Regnumber" type="text" placeholder="Service Provider Register Number">
                    <br>
                    <input name="email" id="Email" type="email" placeholder="Email Address">
                    <br>
                    <input type="submit" id="updateSP" name="updateSP" class="submitBnt" value="Update SP">
                </form>
            </div>

        </div>
    </section>
    <!-- editSP section -->

    <!-- edit customer section -->
    <section id="editcustomer" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Edit Customer</h2>
                <p class="wow fadeInDown animated">Enter NIC number to update Customer</p>
                <br>
                <div class=" conForm" id="editCusForm">
                    <form method="post" name="regNumForm" id="regNumform">
                    <input name="nic" id="nic" type="Text" required placeholder="Enter NIC Number"><br>
                    <input type="submit" style="width: 220px;" id="getcustomer" name="getcustomer" class="submitBnt" value="Get Customer" >
                    </form>

                </div>
            </div>

            <div class=" conForm" id="customerDetails" style="display: none;">
                <form method="post" name="customerDetailsform" id="customerDetailsform" action="adminPanel.php">
                    <input name="fname" id="fname" type="text" placeholder="First Name">
                    <br>
                    <input name="lname" id="lname" type="text" placeholder="Last Name">
                    <br>
                    <input name="dob" id="dob" type="date" placeholder="Date of Birth">
                    <br>
                    <input name="nic" id="nic" type="text" placeholder="NIC Number">
                    <br>
                    <input name="mnumber" id="mnumber" type="number" placeholder="Mobile Number">
                    <br>
                    <input name="email" id="email" type="email" placeholder="Email Address">
                    <br>
                    <input type="submit" style="width: 250px;" id="updateCustomer" name="updateCustomer" class="submitBnt" value="Update Customer">
                </form>
            </div>

        </div>
    </section>
    <!-- edit customer section -->

    <!-- inquiries section -->
    <section id="inquireies" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">All Unreaded Inquiries</h2>
            </div>
            <table>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Message</th>

                </tr>

                <?php
                require_once "connection.php";

                $sql = "SELECT * FROM inqurie WHERE status ='unread';";
                $result = $con->query($sql);

                if ($result->num_rows > 0) {

                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>". $row["inqurie_id"]."</td><td>". $row["sender_name"] . "</td><td>" . $row["email"] . "</td><td>"
                            . $row["subject"] . "</td><td>". $row["message"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    //echo "0 results";
                }
                $sql = "UPDATE inqurie set status ='read' WHERE status ='unread';";
                $result_1 = $con->query($sql);
                if($result_1){

                    //message has sent successfully!
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error; 
                }
            
                ?>

            </table>
        </div>
    </section>
    <!-- inquiries section -->

    <section id="events" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">All Ongoing Events</h2>
            </div>
            <table>
                <tr>
                    <th>Event Id</th>
                    <th>Bill Id</th>
                    <th>Event Name</th>
                    <th>Venue</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Total</th>
                </tr>

                <?php
                require_once "connection.php";

                $sql = "SELECT * FROM event WHERE status ='ongoing';";
                $result_2 = $con->query($sql);

                unset($row);
                if ($result_2->num_rows > 0) {

                    while ($row = $result_2->fetch_assoc()) {
                        $eventid = $row['event_id'];
                        $sql = "SELECT * FROM bill WHERE event_id ='$eventid';";
                        $result_3 = $con->query($sql); 
                        $row_1 = mysqli_fetch_array($result_3, MYSQLI_ASSOC);   

                        echo "<tr><td>". $row["event_id"]."</td><td>". $row_1["bill_id"] . "</td><td>" . $row["event_name"] . "</td><td>"
                            . $row["venue"] . "</td><td>". $row["date"] ."</td><td>". $row["start_time"]. "</td><td>". $row_1["total"]."</td></tr>";
                        unset($result_3);
                        unset($row_1);
                    }
                    echo "</table>";
                } else {
                    //echo "0 results";
                }

                $today = date("Y-m-d");
                $today_time = strtotime($today);
                $sql = "UPDATE event set status = 'done' WHERE status ='ongoing' and date < '$today';";
                $result_3 = $con->query($sql);

                if($result_3){
                    //db updated!
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error; 
                }
                
                ?>

            </table>
            <!-- </div> -->
            <!-- </div> -->
        </div>
    </section>

    <!-- JS FILES -->
    <script src="../../../ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/jquery.countdown.js"></script>
    <script type="text/javascript" src="js/global.js"></script>
    <script type="text/javascript" src="js/jquery.contact.js"></script>
    <script type="text/javascript">
    </script>

    <?php
    require_once "connection.php";

    if(!empty($_POST['addSP'])){

        $error = FALSE;

        if(empty($_POST['name'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the company name ")</script>'; 
        }else if(empty($_POST['address'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the company address ")</script>'; 
        }
        else if(empty($_POST['mnumber'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the contact number ")</script>'; 
        }
        else if(empty($_POST['regnumber'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the bussiness registration number ")</script>'; 
        }
        else if(empty($_POST['sptype'])){
            $error = TRUE;
            echo '<script>alert("Please select the service provider type ")</script>'; 
        }
        else if(empty($_POST['email'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the email address ")</script>'; 
        }
        else if(empty($_POST['password'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the password ")</script>'; 
        }
        else if(empty($_POST['cpassword'])){
            $error = TRUE;
            echo '<script>alert("Please confirm the password ")</script>'; 
        }
        else{

            $name = $_POST["name"];
            $address = $_POST["address"];
            $regnum = $_POST["regnumber"];
            $mnumber = $_POST["mnumber"];
            $email = $_POST["email"];
            $sptype = $_POST["sptype"];
            $password = $_POST["password"];
            $cpassword = $_POST["cpassword"];
            $sec_q = $_POST["sec_q"];
            $sec_a = $_POST["sec_a"];
    
            $name = stripcslashes($name);
            $address = stripcslashes($address);  
            $regnum = stripcslashes($regnum);
            $mnumber = stripcslashes($mnumber); 
            $email = stripcslashes($email); 
            $sptype = stripcslashes($sptype);
            $password = stripcslashes($password); 
            $cpassword = stripcslashes($cpassword); 
            $sec_q = stripcslashes($sec_q); 
            $sec_a = stripcslashes($sec_a); 
     
            $name = mysqli_real_escape_string($con, $name);
            $address = mysqli_real_escape_string($con, $address);
            $regnum = mysqli_real_escape_string($con, $regnum);
            $mnumber = mysqli_real_escape_string($con, $mnumber);
            $email = mysqli_real_escape_string($con, $email);
            $sptype = mysqli_real_escape_string($con, $sptype);
            $password = mysqli_real_escape_string($con, $password);
            $cpassword = mysqli_real_escape_string($con, $cpassword);
            $sec_a = mysqli_real_escape_string($con, $sec_a);
            $sec_q = mysqli_real_escape_string($con, $sec_q);

        }

        if(!$error){
            if(strlen($mnumber) != 10){
                $error = TRUE;
                echo '<script>alert("Please Enter a valid mobile number ")</script>'; 
            }
            else if($password != $cpassword){
                $error = TRUE;
                echo '<script>alert("Passwords does not match ")</script>'; 
            }
            else if (strlen($password) < 7){
                $error = TRUE;
                echo '<script>alert("Password should contain at least 8 characters")</script>';
            }
            else{
                $sql = "SELECT * FROM user where user_name='$name';";
                $result_3 = $con-> query($sql);
                if($result_3){

                if($result_3->num_rows > 0){
                    $error = TRUE;
                    echo '<script>alert("User name already taken ")</script>'; 
                }
                else{
                    $sql = "INSERT INTO user VALUES (0,'$name','$password','service provider','$sec_q','$sec_a','$email');";
                    $result = $con-> query($sql);
        
                    if($result){
                        $sql = "SELECT * FROM `user` WHERE user_id=(SELECT MAX(user_id) FROM `user`);";
                        $result_1 = $con-> query($sql);
                        $row = mysqli_fetch_array($result_1, MYSQLI_ASSOC);
                        $userid = $row['user_id'];
        
                        $sql = "INSERT INTO service_provider VALUES (0,'$regnum','$sptype','$address','$name','$userid','$mnumber');";
                        $result_2 = $con-> query($sql);
                        if($result_2){
                            echo '<script>alert("Account created successfully!")</script>';
                        }
                        else{
                            echo "Error in ".$sql."<br>".$con->error;
                        } 
                    }
                    else{
                        echo "Error in ".$sql."<br>".$con->error;
                    }
            
                }
            }
            }
        }

    }
    else if(!empty($_POST['getSP'])){
        $error = FALSE;
        if(empty($_POST['email'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the Company Email Address ")</script>'; 
        }
        else if(!$error){

            $email = $_POST['email']; 
            $email = stripcslashes($email);  
            $email = mysqli_real_escape_string($con, $email);  
         
            $sql = "SELECT * FROM user WHERE email = '$email';";
            $result = $con-> query($sql);
     
            if($result){
     
                if($result->num_rows > 0){
                    while($row = mysqli_fetch_array($result)){
                        $userid = $row['user_id'];
                        $_SESSION['userid'] = $userid;

                        $sql = "SELECT * FROM service_provider WHERE user_id = '$userid';";
                        $result = $con-> query($sql);
                        if($result){
                            while($row_1 = mysqli_fetch_array($result)){

                                echo '<script>                     
                                var x = document.getElementById("spDetails");
                                if (window.getComputedStyle(x).display === "none") {
                                    x.style.display = "block";   
                                }</script>';
                                $field1 = $row_1['name'];
                                $field2 = $row_1['address'];
                                $field3 = $row_1['contact'];
                                $field4 = $row_1['sp_reg_number'];
                                $field5 = $row['email'];

                                $spid = $row_1['sp_id'];
                                $_SESSION['spid'] = $spid;

                                $_SESSION['field1'] = $field1;
                                $_SESSION['field2'] = $field2;
                                $_SESSION['field3'] = $field3;
                                $_SESSION['field4'] = $field4;
                                $_SESSION['field4'] = $field5;
                                echo '<script>alert("Service Provider found! Fill the Field you need to update")</script>';
                            }

                        }
                        else{
                            echo "Error in ".$sql."<br>".$con->error;
                        }

          
                    }
                }
                else{
                    echo '<script>alert("There is no Company registered for that email address")</script>';
                    $error = FALSE;
                }
    
            }
            else{
                echo "Error in ".$sql."<br>".$con->error;
            }
        }
    }
    else if(!empty($_POST['updateSP'])){
        $error = FALSE;

        global $field1;
        global $field2;
        global $field3;
        global $field4;
        global $field5;

        $user_id = $_SESSION['userid'];
        $sp_id = $_SESSION['spid'];

        $namechng = FALSE;
        $addresschng = FALSE;
        $emailchng = FALSE;
        $regnumchng = FALSE;
        $mnumberchng = FALSE;

        
        if(!empty($_POST['name'])){

            if($field1 != $_POST['name']){
                $namechng = TRUE;
            }
        }else if(!empty($_POST['address'])){
           
            if($field2 != $_POST['address']){
                $addresschng = TRUE;
            }
        }
        else if(!empty($_POST['mnumber'])){
            
            if($field3 != $_POST['mnumber']){
                $mnumberchng = TRUE;
            }
        }
        else if(!empty($_POST['regnumber'])){
           
            if($field4 != $_POST['regnumber']){
                $regnumchng = TRUE;
            }
        }
        else if(!empty($_POST['email'])){
           
            if($field5 != $_POST['email']){
                $emailchng = TRUE;
            }
        }
        else if(strlen($_POST['mnumber']) != 10){
            $error = TRUE;
            echo '<script>alert("Please Enter a valid mobile number ")</script>'; 
        }

        if(!$error){
            if($namechng){

                $newspname = $_POST['name'];
                $sql = "UPDATE service_provider set `name` = '$newspname' WHERE sp_id = '$sp_id';";
                $result = $con-> query($sql);
                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

                $sql = "UPDATE user set user_name = '$newspname' WHERE user_id = '$user_id';";
                $result = $con-> query($sql);
                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }

            if($addresschng){
                $newspaddress = $_POST['address'];
                $sql = "UPDATE service_provider set address = '$newspname' WHERE sp_id = '$sp_id'";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }

            if($mnumberchng){
                $newspmnumber = $_POST['mnumber'];
                $sql = "UPDATE service_provider set mnumber = '$newspmnumber' WHERE sp_id = '$sp_id'";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }
          
            if($regnumchng){
                $newspregnumber = $_POST['regnumber'];
                $sql = "UPDATE service_provider set sp_reg_number = '$newspregnumber' WHERE sp_id = '$sp_id'";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }

            
            if($emailchng){
                $newspemail = $_POST['email'];
                $sql = "UPDATE user set email = '$newspemail' WHERE user_id = '$user_id'";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }
            echo '<script>alert("Service Provider information updated successfully! ")</script>'; 

        }

    }
    else if(!empty($_POST['getcustomer'])){
        $error = FALSE;
        if(empty($_POST['nic'])){
            $error = TRUE;
            echo '<script>alert("Please Enter the Customer NIC Number ")</script>'; 
        }
        else if(!$error){

            $nic = $_POST['nic']; 
            $nic = stripcslashes($nic);  
            $nic = mysqli_real_escape_string($con, $nic);  
         
            $sql = "SELECT * FROM customer WHERE nic = '$nic';";
            $result = $con-> query($sql);
     
            if($result){
     
                if($result->num_rows > 0){
                    while($row = mysqli_fetch_array($result)){
                        $userid = $row['user_id'];
                        $_SESSION['userid'] = $userid;
                        $customerid = $row['customer_id'];
                        $_SESSION['customerid'] = $customerid;

                        $sql = "SELECT * FROM user WHERE user_id = '$userid';";
                        $result = $con-> query($sql);
                        if($result){
                            while($row_1 = mysqli_fetch_array($result)){

                                echo '<script>                       
                                var x = document.getElementById("customerDetails");
                                if (window.getComputedStyle(x).display === "none") {
                                    x.style.display = "block";
                                }</script>';

                                $field6 = $row['first_name'];
                                $field7 = $row['last_name'];
                                $field8 = $row['dob'];
                                $field9 = $row['nic'];
                                $field10 = $row['phone_number'];
                                $field11 = $row_1['email'];

                                $_SESSION['field6'] = $field6;
                                $_SESSION['field7'] = $field7;
                                $_SESSION['field8'] = $field8;
                                $_SESSION['field9'] = $field9;
                                $_SESSION['field10'] = $field10;
                                $_SESSION['field11'] = $field11;

                                echo '<script>alert("Customer found! Fill the Field you need to update")</script>';
                            }

                        }
                        else{
                            echo "Error in ".$sql."<br>".$con->error;
                        }

          
                    }
                }
                else{
                    echo '<script>alert("There is no Customer registered for that NIC number")</script>';
                    $error = FALSE;
                }
    
            }
            else{
                echo "Error in ".$sql."<br>".$con->error;
            }
        }
    }
    else if(!empty($_POST['updateCustomer'])){
        $error = FALSE;

        global $field6;
        global $field7;
        global $field8;
        global $field9;
        global $field10;
        global $field11;

        $user_id = $_SESSION['userid'];
        $customer_id = $_SESSION['customerid'];

        $fnamechng = FALSE;
        $lnamechng = FALSE;
        $dobchng = FALSE;
        $Emailchng = FALSE;
        $nicchng = FALSE;
        $Mnumberchng = FALSE;

        
        if(!empty($_POST['fname'])){

            if($field6 != $_POST['fname']){
                $fnamechng = TRUE;
            }
        }else if(!empty($_POST['lname'])){
           
            if($field7 != $_POST['lname']){
                $lnamechng = TRUE;
            }
        }
        else if(!empty($_POST['dob'])){
            
            if($field8 != $_POST['dob']){
                $dobchng = TRUE;
            }
        }
        else if(!empty($_POST['nic'])){
           
            if($field9 != $_POST['nic']){
                $nicchng = TRUE;
            }
        }
        else if(!empty($_POST['mnumber'])){
           
            if($field10 != $_POST['mnumber']){
                $Mnumberchng = TRUE;
            }
        }
        else if(!empty($_POST['email'])){
           
            if($field11 != $_POST['email']){
                $Emailchng = TRUE;
            }
        }
        else if(strlen($_POST['mnumber']) != 10 && !empty($_POST['mnumber'])){
            $error = TRUE;
            echo '<script>alert("Please Enter a valid mobile number ")</script>'; 
        }

        if(!$error){
            if($fnamechng){

                $newcfname = $_POST['fname'];
                $sql = "UPDATE customer set `first_name` = '$newcfname' WHERE customer_id = '$customer_id';";
                $result = $con-> query($sql);
                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }


                $sql = "UPDATE user set user_name = '$newcfname' WHERE user_id = '$user_id';";
                $result = $con-> query($sql);
                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }

            if($lnamechng){
                $newclname = $_POST['lname'];
                $sql = "UPDATE customer set last_name = '$newclname' WHERE customer_id = '$customer_id';";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }

            if($Mnumberchng){
                $newcmnumber = $_POST['mnumber'];
                $sql = "UPDATE customer set phone_number = '$newcmnumber' WHERE customer_id = '$customer_id';";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }
          
            if($nicchng){
                $newcnic = $_POST['nic'];
                $sql = "UPDATE customer set nic = '$newcnic' WHERE customer_id = '$customer_id'";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }

            if($dobchng){
                $newcdob = $_POST['dob'];
                $sql = "UPDATE customer set dob = '$newcdob' WHERE customer_id = '$customer_id'";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }
            
            if($Emailchng){
                $newcemail = $_POST['email'];
                $sql = "UPDATE user set email = '$newspemail' WHERE user_id = '$user_id';";
                $result = $con-> query($sql);

                if($result){
                    //success
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }

            }
            echo '<script>alert("Customer information updated successfully! ")</script>'; 

        }

    }

?>
</body>

</html>