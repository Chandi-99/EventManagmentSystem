<!doctype html>
<html class="no-js" lang="">

<head>
<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="webthemez.com">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Event Managment System</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/flexslider.css">
<link rel="stylesheet" href="css/jquery.fancybox.css">
<link rel="stylesheet" href="css/main.css"> 
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/font-icon.css">
<link rel="stylesheet" href="css/animate.min.css">
</head>

<body>
<!-- header section -->
<section class="banner" role="banner" id="banner">
  <header id="header">
    <div class="header-content clearfix"> <span class="logo"><a href="index.php">BEST<b>Events</b></a></span>
      <nav class="navigation" role="navigation">
        <ul class="primary-nav">
		      <li><a href="#banner">Home</a></li>
          <li><a href="serviceProviderPanel.php">Dashboard</a></li>
          <li><a href="#intro">About</a></li>
          <li><a href="#events">Events</a></li>
          <li><a href="#gallery">Gallery</a></li>
		      <!-- <li><a href="#package">Tickets</a></li> -->
          <li><a href="#contact">Contact</a></li>
          <li><a href="login.php">LogOut</a></li>
        </ul>
      </nav>
      <a href="#" class="nav-toggle">Menu<span></span></a> </div>
  </header>
  <!-- banner text -->
  <div class="container">
    <div class="col-md-10">
      <div class="banner-text text-center">
        <h1>Event Management</h1>
        <p>"A goal without a plan is just a wish"</p> 
		<div class="countdown styled"></div>
		</div>
      <!-- banner text --> 
    </div>
  </div>
</section>
<!-- header section --> 

<!-- intro section -->
<section id="intro" class="section intro">
  <div class="container">
    <div class="col-md-8 col-md-offset-2 text-center">

      <h3>About Us</h3>
      <p>The goal of <b>'Best Events'</b> is to provide proper event management planning for your any successful event. Our main objective is to  establish, how all the unique moving parts and different elements of your event will work and make your event safe and enjoyable.
     <br><br> Our company is a combination of four different minds who always gives unlimited care and extends a friendly hand to help and organize one’s dream event on a grand scale to the utmost satisfaction of the dreamer.
Our company has involved in many types of events such as below and marked the Best Events name on our Sri Lankan and overseas clients minds.</p> 
        
    </div>
  </div>
</section>
<!-- intro section --> 
<!-- services section -->
<section id="services" class="services service-section">
  <div class="container">
  <div class="section-header">
                <h2 class="wow fadeInDown animated">Our Working Process</h2>
                <p class="wow fadeInDown animated"><br> </p>
            </div>
    <div class="row"> 
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-recycle"></span>
        <div class="services-content">
          <h5>Finding The Perfect Venue For Your Event</h5>
		 
        </div>
      </div>
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-heart"></span>
        <div class="services-content">
          <h5>Connecting with the best vendor</h5>
		  
        </div>
      </div> 
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-megaphone"></span>
        <div class="services-content">
          <h5>Organizing Your Event</h5>
		 <br>
        </div>
      </div> 
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-briefcase"></span>
        <div class="services-content">
          <h5>Enjoy the party with your friends</h5>
		  
        </div>
      </div> 
    </div>
  </div>
</section> 
<!-- services section -->
<!-- event section -->
<section id="events" class="section teams"> 
	<div class="container">
	    <div class="section-header">
                <h2 class="wow fadeInDown animated">Events</h2>
                <p class="wow fadeInDown animated"><font size="4px" color="black">An event is something exciting, memorable and unique to the event owner & most of the time it’s a dream.
                   Today, the ideas of people are very advanced through the time factor matters with their busy schedule.
                    However, Success of a dream can become invaluable for the happiness of the dreamer.
                    <br></font></p>
            </div>
		<div class="row">
			<div class="col-md-6">
				<img src="images/pic2.jpg" class="img-responsive" alt="">
			</div>
			<div class="col-md-6">
				<div class="col-md-11">
					<h3><b>Our Upcoming Events</b></h3>
					<ul class="tour-list">
						<li>
							<div class="tour-date" >16<span>Feb<br><em>2021</em></span></div>
							<div class="tour-info">Hilton Hotel, Colombo - <a href="#">Engagement</a></div>
							<div class="tour-ticket"></div>
						</li>
						<li>
							<div class="tour-date">22<span>Mar<br><em>2021</em></span></div>
							<div class="tour-info">Kingsburry Hotel, Colombo - <a href="#">Wedding</a></div>
							<div class="tour-ticket"></div>
						</li>
						<li>
							<div class="tour-date">12<span>April<br><em>2021</em></span></div>
							<div class="tour-info">Sanhida, Rajagiriya - <a href="#">Birthday Party</a></div>
							<div class="tour-ticket"></div>
						</li>
						<li>
							<div class="tour-date">26<span>April<br><em>2021</em></span></div>
							<div class="tour-info">Bishop's college auditorium - <a href="#">Musical Show</a></div>
							<div class="tour-ticket"></div>
						</li>
						<li>
							<div class="tour-date">10<span>June<br><em>2021</em></span></div>
							<div class="tour-info">Cinnamon Grand Hotel - <a href="#">Conference</a></div>
							<div class="tour-ticket"></div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
 </section>
 <!-- event section -->
<!-- gallery section -->
<section id="gallery" class="gallery section">
  <div class="container-fluid">
    <div class="section-header">
                <h2 class="wow fadeInDown animated">Gallery</h2>
                <p class="wow fadeInDown animated">Please visit our Facebook page for more pictures</p>
            </div>
    <div class="row no-gutter">
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/01.jpg" class="work-box"> <img src="images/portfolio/01.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
             <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/02.jpg" class="work-box"> <img src="images/portfolio/02.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/03.jpg" class="work-box"> <img src="images/portfolio/03.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/04.jpg" class="work-box"> <img src="images/portfolio/04.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption"> 
            <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
        <!-- overlay --> 
      </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/05.jpg" class="work-box"> <img src="images/portfolio/05.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
             <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/06.jpg" class="work-box"> <img src="images/portfolio/06.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/07.jpg" class="work-box"> <img src="images/portfolio/07.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/portfolio/08.jpg" class="work-box"> <img src="images/portfolio/08.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption"> 
            <p><span class="icon icon-magnifying-glass"></span></p>
          </div>
        </div>
        <!-- overlay --> 
      </a> </div>
      
    </div>
  </div>
</section>
<!-- gallery section --> 

<!-- contact section -->
<section id="contact" class="section">
  <div class="container">
      <div class="section-header">
                <h2 class="wow fadeInDown animated">Contact Us</h2>
                <p class="wow fadeInDown animated">Contacts us for any inquiry or feedback</p>
            </div>
    <div class="row">
      <div class="col-md-6 conForm">       
        <div id="message"></div>
        <form method="post" action="index.php" name="cform" id="cform">
          <input name="name" id="name" type="text" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" placeholder="Your name..." >
          <input name="email" id="email" type="email" class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 noMarr" placeholder="Email Address..." >
          <input name="subject" id="subject" type="text" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" placeholder="Subject..." >         
          <textarea name="comments" id="comments" cols="" rows="" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" placeholder="Message..."></textarea>
          <input type="submit" id="submit" name="send" class="submitBnt" value="Send">
          <div id="simple-msg"></div>
        </form>
      </div>
	  
	      <div class="col-xs-3" >
    		<h3 style="margin-top:0;color:#fff;">Our Address</h3>
    		<address style="color:#fff;">
    			<strong>Best Events</strong><br>
    			143. R De Mel Mawatha,<br>
    			Bambalapitya,<br>
    			Colombo - 04.<br>
    			Sri Lanka.<br>
    			<abbr title="Phone">Tel:</abbr> +(94) 11 123 45678
    		</address>
        <p>follow us on:</p>
        <a  href="https://www.facebook.com/"><img src="/fb.png" width="40px" height="40px" style="margin:5px 5px;"></a>
        <a  href="https://www.instagram.com/"><img src="/ig.jpg" width="40px" height="40px" style="margin:5px 5px;"/></a>
        <a  href="https://www.twitter.com/"><img src="/tw.png" width="40px" height="40px" style="margin:5px 5px;"/></a>
        <a  href="https://www.linkedin.com/"><img src="/in.png" width="40px" height="40px" style="margin:5px 5px;"/></a>
			   <!-- <a target="_blank" href="https://www.templateshub.net" title="Bootstrap Themes and HTML Templates">Templates Hub</a> -->
    	</div>
      <div class="col-xs-3" >
    		<h3 style="margin-top:0;color:#fff;">Our Top Partners</h3>
        <strong style="color:#fff;">Lassana Flora</strong><br>
        <strong style="color:#fff;">Hilton Hotel</strong><br>
        <strong style="color:#fff;">Studio 3000</strong><br>
        <strong style="color:#fff;">Lanka Express Transport & Logistics</strong><br>

</div>
		
    </div>
  </div>
</section>
<!-- JS FILES --> 
<script src="../../../ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flexslider-min.js"></script> 
<script src="js/jquery.fancybox.pack.js"></script>  
<script src="js/modernizr.js"></script> 
<script src="js/main.js"></script> 
<script type="text/javascript" src="js/jquery.countdown.js"></script>
<script type="text/javascript" src="js/global.js"></script>
<script type="text/javascript" src="js/jquery.contact.js"></script> 

<script type="text/javascript">

</script>
</body>

<?php

require_once "connection.php";
$error = FALSE;

if(isset($_POST['send'])){

  if(empty($_POST['name'])){
    $error = TRUE;
    echo '<script>alert("Please Enter the name ")</script>'; 
  }else if(empty($_POST['email'])){
    $error = TRUE;
    echo '<script>alert("Please Enter the email address ")</script>'; 
  }
  else if(empty($_POST['subject'])){
    $error = TRUE;
    echo '<script>alert("Please Enter the subject of the message ")</script>'; 
  }
  else if(empty($_POST['comments'])){
    $error = TRUE;
    echo '<script>alert("Please Enter the message ")</script>'; 
  } 

  if(!$error){

    $name = $_POST["name"];
$email = $_POST["email"];
$subject = $_POST["subject"];
$comments = $_POST["comments"];

$name = stripcslashes($name);  
$email = stripcslashes($email); 
$subject = stripcslashes($subject);  
$comments = stripcslashes($comments);

$name = mysqli_real_escape_string($con, $name);  
$email = mysqli_real_escape_string($con, $email);
$subject = mysqli_real_escape_string($con, $subject);
$comments = mysqli_real_escape_string($con, $comments);

echo'<script type="text/javascript">

function validate(){
    var un = document.getElementById("username");
    var pass = document.getElementById("password");

    if(un == "" || pass == ""){
        alert("Please fill all the required fields");
    }
}
</script>';

if(isset($_SESSION['customer_id'])){
    $customerid = $_SESSION['customer_id'];
    $sql = "INSERT INTO inqurie VALUES (0,'$name','$comments','$subject','$email',1,'$customerid','unread')";
    $result = $con-> query($sql);
    if($result){
        echo '<script>alert("Message has sent successfully!")</script>';
        $_SESSION['customer_id'] = $customerid;
        //header("Location:index.php");
    }
    else{
        echo "Error in ".$sql."<br>".$con->error;
    } 

}else if(isset($_SESSION['sp_id'])){
    $spid = $_SESSION['sp_id'];
    $sql = "INSERT INTO inqurie VALUES (0,'$name','$comments','$subject','$email','$spid',1,'unread')";
    $result = $con-> query($sql);
    if($result){
        echo '<script>alert("Message has sent successfully!")</script>';
        $_SESSION['sp_id'] = $spid;
        //header("Location:index.php");
    }
    else{
        echo "Error in ".$sql."<br>".$con->error;
    } 
}
else{
    $sql = "INSERT INTO inqurie VALUES (0,'$name','$comments','$subject','$email',1,1,'unread');";
    $result = $con-> query($sql);
    if($result){
        echo '<script>alert("Message has sent successfully!")</script>';
        //header("Location:index.php");
    }
    else{
        echo "Error in ".$sql."<br>".$con->error;
    } 
}
  }
}



?>

</html>