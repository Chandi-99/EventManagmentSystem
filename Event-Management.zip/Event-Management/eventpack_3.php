<?php
require_once "connection.php";
session_start();
$error = FALSE;

if(empty($_SESSION['customer_id'])){
    echo '<script>alert("Please Log into the system")</script>';
    header("Location:login.php");
}
else{
    $customerid = $_SESSION['customer_id'];
    $eventid = $_SESSION['event_id'];
    //$eventid = 1;
}
?>
<!doctype html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css"> 
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">

    <style rel="stylesheet" type="text/css">

    select{
        color: #797979;
	    padding: 15px 30px;
	    width:500px;
	    border: none;
	    margin-bottom: 30px;
	    outline: none;
	    font-style: normal;
	    border: #e0e0e0 1px solid;
	    font-size: 15px;
	    background: #010101;
    }

        </style>
    </head>

<body>
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="index.php">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index_new_1.php">Home</a></li>
                    <li><a href="login.php">Logout</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>
    <section  class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Decorations</h2>
                <p class="wow fadeInDown animated">Select the Service Provider you want</p>
                <br>
            </div>
        <div class="row">
    <div class=" conForm">

    <form method="post" action = "eventpack_3.php">
    <select name="sp">  
        
<?php

$error = FALSE;
if(!$error){
    global $eventid;
    global $customerid;
 
    $sql = "SELECT * FROM service_provider WHERE sp_type = 'decoration';";
    $result = $con-> query($sql);

    if($result){      
        if($result->num_rows > 0){
            while($row = mysqli_fetch_array($result)){
                echo $row['name'];
            ?>                       
            <option><?php echo $row['name'] ?></option>
            <?php
            }           
        }       
    }
    else{
        echo "Error in ".$sql."<br>".$con->error;
    }
}
?>
    </select><br>
    <input type="submit" name="skip" class="submitBnt" action="eventpack_3.php" value="Skip" style="width:60px; height:40px; padding:10px;"><br>
    <input type="submit" id="addSP" name="addsp" class="submitBnt" value="Select SP">
    </form>
    <form method="post" action = "eventpack_3.php">
    <select name="pack" style="margin-right:10px;"> 
   

<?php
if(isset($_POST['skip'])){
    $error = FALSE;
    $_SESSION['event_id'] = $eventid;
    $_SESSION['customer_id'] = $customerid;
    header("Location:eventpack_4.php");
}
else if(isset($_POST['addsp'])){
    $error = FALSE;
    if(empty($_POST['sp'])){
        $error = TRUE;
        echo '<script>alert("Please select the Service Provider")</script>';
    }

    if(!$error){
        global $eventid;
        global $customerid;

        $spname = $_POST['sp'];
        $sql = "SELECT * FROM service_provider WHERE name = '$spname';";
        $result = $con-> query($sql);

        if($result){
            while($row = mysqli_fetch_array($result)){
                $spid = $row['sp_id'];
                $_SESSION['new'] = $spid;
            }

            $sql = "SELECT * FROM package WHERE sp_id = '$spid';";
            $result = $con-> query($sql);

            if($result){
                if($result->num_rows > 0){
                    while($row = mysqli_fetch_array($result)){
                        //echo $row['name'];
                    ?>                          
                    <option><?php echo $row['package_name'] ?></option>
                    <?php
                    }
                    
                }  
            }
        }
        else{
            echo "Error in ".$sql."<br>".$con->error;
        }
    }

}
?>
</select>
<input type="submit" id="addSP" name="addpack" class="submitBnt" value="Add Package">
<?php

if(isset($_POST['addpack'])){
    $error = FALSE;
    if(empty($_POST['pack'])){
        $error = TRUE;
        echo '<script>alert("Please select the package")</script>';
    }

    if(!$error){
        global $eventid;
        global $customerid;

        $packname = $_POST['pack'];
        $new = $_SESSION['new'];
        $sql = "SELECT * FROM package WHERE package_name = '$packname';";
        $result = $con-> query($sql);

        if($result){
            while($row = mysqli_fetch_array($result)){
                $packageid = $row['package_id'];
            }

            $sql = "INSERT into sp_event values('$new','$eventid','$packageid');";
            $result = $con-> query($sql);

            if($result){                   
                        echo '<script>alert("Package added successfully!")</script>';
                        $_SESSION['event_id'] = $eventid;
                        $_SESSION['customer_id'] = $customerid;
                        header("Location:eventpack_4.php");
            }
            else{
                echo "Error in ".$sql."<br>".$con->error;
            }
        }
        else{
            echo "Error in ".$sql."<br>".$con->error;
        }

    }
    
}
?>                
</div>
</div>
</div>
</section>
</body>

</html>
