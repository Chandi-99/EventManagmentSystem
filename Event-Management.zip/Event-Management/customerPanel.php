<?php

require_once "connection.php";
session_start();
if(empty($_SESSION['customer_id'])){
    echo '<script>alert("Please Log into the system")</script>';
   // header("Location:login.php");
}
else{
    $customerid = $_SESSION['customer_id'];
}

$error = FALSE;

?>
<!doctype html>
<html class="no-js" lang="">


<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css"> 
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">

    <style rel="stylesheet" type="text/css">

    select{
        color: #797979;
	    padding: 15px 30px;
	    width:500px;
	    border: none;
	    margin-bottom: 30px;
	    outline: none;
	    font-style: normal;
	    border: #e0e0e0 1px solid;
	    font-size: 15px;
	    background: #010101;
    }

        </style>
    </head>

<body>
    <!-- header section -->
    <!-- <section class="banner" role="banner" id="banner"> -->
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="index.php">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index_new_1.php">Home</a></li>
                    <li><a href="login.php">Logout</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>

    <section id="services" class="services service-section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated" id="cus_name">Hello Customer</h2>
               
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-recycle"></span>
                    <div class="services-content">
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-heart"></span>
                    <div class="services-content">
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 services text-center"> <span class="icon icon-megaphone"></span>
                    <div class="services-content">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="newSP" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Start Your New Event here</h2>
                <p class="wow fadeInDown animated">Fill the required field to create an event</p>
                <br>
            </div>
            <div class="row">
                <div class=" conForm">
                    <form method="post"  action="customerPanel.php">
                        <input name="name" id="name" type="text" placeholder="Event Name">
                        <br>
                        <select name="event_type">   
                        <option>Weddings & homecomings</option>
                        <option>Engagements</option>
                        <option>Anniversaries</option>
                        <option>Proposals & surprises</option>
                        <option>Birthday parties</option>
                        <option>Theme events</option>
                        <option>Fashion shows</option>
                        <option>Concerts</option>
                        </select>
                        <br>
                        <input name="date" type="date" onfocus="(this.type ='date')" onblur="(this.type='text')" placeholder="Date">
                        <br>
                        <input name="count" type="number" placeholder="Participant Count">
                        <br>
                        <input name="str_time" id="str_time" type="time" placeholder="Start time" onfocus="(this.type ='time')" onblur="(this.type='text')" placeholder="Date">
                        <br>
                        <input name="end_time" id="end_time" type="time" placeholder="End time" onfocus="(this.type ='time')" onblur="(this.type='text')" placeholder="Date">
                        <br>
                        <input type="submit" id="addevent" name="addevent" class="submitBnt" value="Create Event">
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php

        $sql = "SELECT * FROM customer WHERE customer_id = '$customerid';";
        $result_3 = $con-> query($sql);
        if($result_3){
            
            $row_3 = mysqli_fetch_array($result_3, MYSQLI_ASSOC);  
            $cus_name = $row_3['first_name'];
        }
        else{
            echo "Error in ".$sql."<br>".$con->error;
        }

        if(isset($_POST['addevent'])){
            $error = FALSE;
            
            if(empty($_POST['name'])){
                $error = TRUE;
                echo '<script>alert("Please Enter the Event name ")</script>'; 
            }
            else if(empty($_POST['count'])){
                $error = TRUE;
                echo '<script>alert("Please Enter the Participant Count")</script>'; 
            }
            else if(empty($_POST['event_type'])){
                $error = TRUE;
                echo '<script>alert("Please Select the Event Type ")</script>'; 
            }
            else if(empty($_POST['date'])){
                $error = TRUE;
                echo '<script>alert("Please Enter Date ofthe Event")</script>'; 
            }
            else if(empty($_POST['str_time'])){
                $error = TRUE;
                echo '<script>alert("Please Enter Start time of the Event")</script>'; 
            }
            else if(empty($_POST['end_time'])){
                $error = TRUE;
                echo '<script>alert("Please Enter End time of the Event")</script>'; 
            }
            else{

                $name = $_POST["name"];
                $type = $_POST["event_type"];
                $date = $_POST["date"];
                $str_time = $_POST["str_time"];
                $end_time = $_POST["end_time"];
                $count = $_POST["count"];

                $name = stripcslashes($name);
                $type = stripcslashes($type);
                $date = stripcslashes($date);  
                $str_time = stripcslashes($str_time);
                $end_time = stripcslashes($end_time);
                $count = stripcslashes($count);  

                $name = mysqli_real_escape_string($con, $name);
                $type = mysqli_real_escape_string($con, $type); 
                $date = mysqli_real_escape_string($con, $date);
                $str_time = mysqli_real_escape_string($con, $str_time);
                $end_time = mysqli_real_escape_string($con, $end_time);
                $count = mysqli_real_escape_string($con, $count);

            }

            if(!$error){
                
                $sql = "SELECT * FROM event where event_name='$name';";
                $result = $con-> query($sql);
                if($result){
                    if($result->num_rows > 0){
                        $error = TRUE;
                        echo '<script>alert("Event Name already taken ")</script>'; 

                    }else{
                        $sql = "INSERT INTO event VALUES (0,'$name','$date','','$count','$customerid','$str_time','$end_time','ongoing');";
                        $result = $con-> query($sql);
    
                        if($result){
                            $sql = "SELECT * FROM `event` WHERE event_id=(SELECT MAX(event_id) FROM `event`);";
                            $result_1 = $con-> query($sql);
                            $row = mysqli_fetch_array($result_1, MYSQLI_ASSOC);
                            $eventid = $row['event_id'];
                            $_SESSION['event_id'] = $eventid;
                            $_SESSION['customer_id'] = $customerid;

                            echo '<script>alert("Event Created Successfully! ")</script>';
                            $url = "eventpack_1.php";

                                if (!headers_sent())
                                {    
                                    header('Location: '.$url);
                                    exit;
                                }
                                else
                                {  
                                    echo '<script type="text/javascript">';
                                    echo 'window.location.href="'.$url.'";';
                                    echo '</script>';
                                    echo '<noscript>';
                                    echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
                                    echo '</noscript>'; exit;
                                }



                            $error = FALSE;
                        }
                    }
                
                }
                else{
                    echo "Error in ".$sql."<br>".$con->error;
                }
            }
        }
        
    ?>  
    <!-- JS FILES -->
    <script src="../../../ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/jquery.countdown.js"></script>
    <script type="text/javascript" src="js/global.js"></script>
    <script type="text/javascript" src="js/jquery.contact.js"></script>
    <script type="text/javascript">
   var php_var = "<?php echo $cus_name; ?>";
   document.getElementById("cus_name").innerHTML =  "Hello " +php_var;
</script>
</body>

</html>