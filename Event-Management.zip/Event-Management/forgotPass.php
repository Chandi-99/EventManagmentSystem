<?php
session_start();
require_once "connection.php";
$error = FALSE;
$question = "";
?>

<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="webthemez.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/font-icon.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <style>
        #new{
            color:red;
            margin-top:0px;
            padding-top:0px;
            font-size:55px;
        }
        </style>
</head>

<body>
    <!-- header section -->
    <!-- <section class="banner" role="banner" id="banner"> -->
    <header id="header">
        <div class="header-content clearfix"> <span class="logo"><a href="index.php">BEST<b>Events</b></a></span>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>

    
    <section id="contact" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="wow fadeInDown animated">Forgot Password</h2>
                <p class="wow fadeInDown animated">Please enter your email</p>
            </div>
            <div class="row">
                <div class=" conForm">
                    <form method="post" action="forgotPass.php" name="lform" id="lform">
                        <input name="email" id="email" type="email" required placeholder="Email Address">
                        <br>
                        <input type="submit" style="width: 325px;"  name="submit1" class="submitBnt"
                            value="Get Security Question" >
                    </form>
                </div>
            </div>
            <!-- get question section -->
            <div class=" conForm" id="securitryQuestion" style="display: none;">
                <p class="wow fadeInDown animated" id="securitryQuestionText"> <?php echo $question; ?> </p><br>
                <form method="post" action="forgotPass.php" name="lform" id="lform">
                    <input name="answer" id="answer" type="Text" required placeholder="Enter Answer"><br>
                    <input type="submit" style="width: 220px;" name="submit2" class="submitBnt"
                        value="Check Answer">
                </form>
                        
                <!-- </form> -->

            </div>
            <!-- get question section -->
            <!-- new password section -->
            <div class=" conForm" id="newPassword" style="display: none;">
            <form method="post" action="forgotPass.php" name="lform" id="lform">
                    <input name="pass1" id="pass1" type="password" required placeholder="Password"><br>
                    <input name="pass2" id="pass2" type="password" required placeholder="Re Enter Password"><br>
                    <input type="submit" style="width: 250px;"  name="submit3"  class="submitBnt"
                        value="Reset Password">
                </form>

            </div>
            <!-- new password section -->
        </div>
    </section>
                
    <!-- forgot password section -->

    <!-- JS FILES -->
    <script src="../../../ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/jquery.countdown.js"></script>
    <script type="text/javascript" src="js/global.js"></script>
    <script type="text/javascript" src="js/jquery.contact.js"></script>
    <script type="text/javascript">
    </script>

<?php

if(!empty($_POST['submit1'])){
    $error = FALSE;
    
    if(empty($_POST['email'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the email address ")</script>'; 
    }
    else if(!$error){
 
        $email = $_POST['email']; 
        $email = stripcslashes($email);  
        $email = mysqli_real_escape_string($con, $email);  
     
        $sql = "SELECT * FROM user WHERE email = '$email';";
        $result = $con-> query($sql);
 
        if($result){
 
            if($result->num_rows > 0){
                while($row = mysqli_fetch_array($result)){
                    $question = $row['security_q'];
                    $userid = $row['user_id'];
                    $_SESSION['userid'] = $userid;
                    echo "<script type=\"text/javascript\">
                    window.onload = function() {
                    document.getElementById('securitryQuestion').style.display = 'block'; 
                    };</script>";
                    echo "<center><h1 id='new'>Security Question:".$question."<h2></center>";           
                }
            }
            else{
            echo '<script>alert("There is no user registered for that email address")</script>';
            $error = FALSE;
            }

        }
    }

}
else if(!empty($_POST['submit2'])){
    //echo '<script>alert("There is no user registered for that email address")</script>';
    $error = FALSE;

    if(empty($_POST['answer'])){
        $error = TRUE;
        echo '<script>alert("Please Enter the answer for the question ")</script>'; 
    }
    else if(!$error){

        $answer = $_POST['answer']; 
        $answer = stripcslashes($answer);  
        $answer = mysqli_real_escape_string($con, $answer); 

        $sql = "SELECT * FROM user WHERE security_a = '$answer';";
        $result_1 = $con-> query($sql);

        if($result_1){
            if($result_1->num_rows > 0){
                while($row_1 = mysqli_fetch_array($result_1)){
                    //echo $question;
                    echo "<script type=\"text/javascript\">
                    window.onload = function() {
                    document.getElementById('newPassword').style.display = 'block';
                    };</script>";               
                }
            }
            else{
                echo '<script>alert("The answer you entered is wrong!")</script>';
                $error = FALSE; 
            }
        }
        else{
            echo "Error in ".$sql."<br>".$con->error;
        }

    }
}
else if(!empty($_POST['submit3'])){
    $error = FALSE;

    if(empty($_POST['pass1'])){
        $error = TRUE;
        echo '<script>alert("Please fill the required fields ")</script>'; 
    }
    else if(empty($_POST['pass2'])){
        $error = TRUE;
        echo '<script>alert("Please fill the required fields ")</script>'; 
    }
    else if(!$error){
        $pass1 = $_POST['pass1']; 
        $pass1 = stripcslashes($pass1);  
        $pass1 = mysqli_real_escape_string($con, $pass1); 

        $pass2 = $_POST['pass2']; 
        $pass2 = stripcslashes($pass2);  
        $pass2 = mysqli_real_escape_string($con, $pass2);

        if($pass1 != $pass2){
            $error = TRUE;
            echo '<script>alert("Passwords does not match!")</script>'; 
        }
        else if (strlen($pass1) < 7){
            $error = TRUE;
            echo '<script>alert("Password should contain at least 8 characters")</script>';
        }
        else{
            $user_id = $_SESSION['userid'];
            $pass1 = $_POST['pass1']; 
            $sql = "UPDATE user set `password` = '$pass1' where user_id = '$user_id';";
            $result_2 = $con-> query($sql);

            if($result_2){
                echo '<script>alert("Password updated successfully! ")</script>';
                echo "<script type=\"text/javascript\">
                window.onload = function() {
                document.getElementById('securitryQuestion').style.display = 'none';
                document.getElementById('newPassword').style.display = 'none';               
                };</script>";  
            }
            else{
                echo "Error in ".$sql."<br>".$con->error;
            }

        }
    }
}

?>
</body>

</html>